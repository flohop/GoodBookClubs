$(document).ready(function() {
    console.log("Loaded script to toggle book read achieve")
    function toggle_achieved(e){

        }
});
